<?php

namespace App\Http\Controllers;
use Illuminate\Support\Facades\Mail;
use App\Models\mode;

use Illuminate\Http\Request;

class form extends Controller
{
    public function register(){
        return view('register');
    }
    public function view(){
        $users=mode::all();
        return view('view',compact('users'));
    }
    public function store(Request $request){
        $request->validate([
             'name'=>'required',
             'mobile'=>'required|numeric|digits:10',
             'email'=>'required|unique:mode',
             'password' => 'min:6',
             'password_confirmation' => 'required_with:password|same:password|min:6'
          ]);
          $name=$request->name;
          $mobile=$request->mobile;
          $address=$request->address;
          $email=$request->email;
          $password=$request->password;
          $password_confirmation=$request->password_confirmation;

          $data = [
            'subject' => $request->address,
            'name' => $request->name,
            'email' => $request->email,
            'content'=>$request->mobile
          ];

          Mail::send('email', $data, function($message) use ($data) {
            $message->to($data['email'])
            ->subject($data['subject']);
          });

    $student=new  mode();
    $student->name= $name;
    $student->mobile=$mobile;
    $student->address=$address;
    $student->email=$email;
    $student->password=$password;
    $student->password_confirmation=$password_confirmation;
    $student->save();

    return redirect('/')->with('student_added','your record has been inserted ');
}
public function edit($id)
{
    $customer=mode::find($id);
    $data=compact('customer');
    return view('edit')->with($data);
    }

public function update($id, Request $request ){
    $request->validate([
        'name'=>'required',
        'mobile'=>'required|numeric|digits:10',
        'email'=>'required|unique:users',
        'password' => 'min:6',
        'password_confirmation' =>'required_with:password|same:password|min:6'
     ]);
$student=mode::find($id);
$student->name=$request['name'];
$student->mobile=$request['mobile'];
$student->address=$request['address'];
$student->email=$request['email'];
$student->password=$request['password'];
$student->password_confirmation=$request['password_confirmation'];
$student->save();
// return view('view')->with('student_added','your record has been updated ');
return redirect('/')->with('student_added','your record has been updated ');
    }
}
