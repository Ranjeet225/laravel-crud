    <!doctype html>
  <html lang="en">
  <head>
    <title>add </title>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <link rel="stylesheet" href="https://www.w3schools.com/w3css/4/w3.css">
    <link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Karma">
    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css" integrity="sha384-ggOyR0iXCbMQv3Xipma34MD+dH/1fQ784/j6cY/iJTQUOhcWr7x9JvoRxT2MZw1T" crossorigin="anonymous">
  <style>.column {
    float: left;
    width: 33.33%;
    padding: 5px;
  }

  /* Clearfix (clear floats) */
  .row::after {
    content: "";
    clear: both;
    display: table;
  }
  </style></style>
  </head>
  <body>
      <section style="">
    <div class="container">
        <div class="row">
           <div class="col-md-12">
      <div class="card ">
    <div class="card-header" style="text-align: center;font-size:45px">
  Register
  <?php if(Session::has('student_added')): ?>
  <div class="alert alert-dark" role="alert">
   <?php echo e(session::get('student_added')); ?>

  </div>
  <?php endif; ?>
    </div>
    <div class="card-body">
    <span>
  <form action="<?php echo e(url('/')); ?>/store"method="POST"enctype="multipart/form-data">
  <?php echo csrf_field(); ?>
  <div class="form-group">
    <label for="name">Name</label>
    <input type="text" name="name"class="form-control" value="<?php echo e(old('name')); ?>"/>
    <span class="text-danger">
       <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
      <?php echo e($message); ?>

    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
  </span>
  </div>
  <div class="form-group">
    <label for="name">  Mobile</label>
    <input type="number" name="mobile" placeholder="+91"  value="<?php echo e(old('mobile')); ?>"class="form-control"/>
    <span class="text-danger">
      <?php $__errorArgs = ['mobile'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
     <?php echo e($message); ?>

   <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
  </span>
  </div>
  <div class="form-group">
    <label for="name">Address</label>
    <input type="text" name="address" placeholder="" value="<?php echo e(old('address')); ?>"class="form-control">

  </div>
  <div class="form-group">
    <label for="name">Email</label>
    <input type="email" name="email" placeholder="" value="<?php echo e(old('email')); ?>"class="form-control">
    <span class="text-danger">
        <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
       <?php echo e($message); ?>

     <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
   </span>
  </div>
  <div class="form-group">
    <label for="name">Password</label>
    <input type="password" name="password"value="<?php echo e(old('password')); ?>" placeholder=""class="form-control">
    <span class="text-danger">
        <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
       <?php echo e($message); ?>

     <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
   </span>
  </div><div class="form-group">
    <label for="name">Confirm password</label>
    <input type="password" name="password_confirmation" value="<?php echo e(old('password_confirmation')); ?>" placeholder=""class="form-control">
    <span class="text-danger">
        <?php $__errorArgs = ['password_confirmation'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
       <?php echo e($message); ?>

     <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
   </span>
  </div>
    <button type="submit"class="btn btn-primary form-control">submit</button>
    </section>
    <!-- Optional JavaScript -->
    <!-- jQuery first, then Popper.js, then Bootstrap JS -->
    <script src="https://code.jquery.com/jquery-3.3.1.slim.min.js" integrity="sha384-q8i/X+965DzO0rT7abK41JStQIAqVgRVzpbzo5smXKp4YfRvH+8abtTE1Pi6jizo" crossorigin="anonymous"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.7/umd/popper.min.js" integrity="sha384-UO2eT0CpHqdSJQ6hJty5KVphtPhzWj9WO1clHTMGa3JDZwrnQq4sF86dIHNDz0W1" crossorigin="anonymous"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/js/bootstrap.min.js" integrity="sha384-JjSmVgyd0p3pXB1rRibZUAYoIIy6OrQ6VrjIEaFf/nJGzIxFDsf4x0xIM+B07jRM" crossorigin="anonymous"></script>
  </body>
  </html>
<?php /**PATH C:\xampp\htdocs\project\resources\views/register.blade.php ENDPATH**/ ?>